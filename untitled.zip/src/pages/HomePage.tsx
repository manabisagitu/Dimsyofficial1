import { useEffect, useState } from "react";
import { collection, query, orderBy, onSnapshot, doc } from "firebase/firestore";
import { db } from "../lib/firebase";
import { ExternalLink, User } from "lucide-react";
import { Link } from "react-router-dom";

interface LinkItem {
  id: string;
  title: string;
  url: string;
  order: number;
}

export default function HomePage() {
  const [links, setLinks] = useState<LinkItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [avatarUrl, setAvatarUrl] = useState("");
  const [broadcastMsg, setBroadcastMsg] = useState("");
  const [broadcastActive, setBroadcastActive] = useState(false);

  useEffect(() => {
    const q = query(collection(db, "links"), orderBy("order", "asc"));
    const unsubscribeLinks = onSnapshot(q, (snapshot) => {
      const linksData = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      })) as LinkItem[];
      setLinks(linksData);
      setLoading(false);
    });

    const unsubscribeProfile = onSnapshot(doc(db, "settings", "profile"), (docSnap) => {
      if (docSnap.exists()) {
        setAvatarUrl(docSnap.data().avatarUrl || "");
      }
    });

    const unsubscribeBroadcast = onSnapshot(doc(db, "settings", "broadcast"), (docSnap) => {
      if (docSnap.exists()) {
        setBroadcastMsg(docSnap.data().message || "");
        setBroadcastActive(docSnap.data().isActive || false);
      }
    });

    return () => {
      unsubscribeLinks();
      unsubscribeProfile();
      unsubscribeBroadcast();
    };
  }, []);

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 font-sans flex flex-col">
      {broadcastActive && broadcastMsg && (
        <div className="bg-gray-900 text-white text-center py-3 px-4 text-sm font-medium w-full">
          {broadcastMsg}
        </div>
      )}
      <header className="flex justify-between items-center p-6 w-full max-w-2xl mx-auto">
        <h1 className="text-2xl font-bold tracking-tight text-gray-900">Dimsy Official</h1>
        <Link 
          to="/login"
          className="text-gray-500 hover:text-gray-900 transition-colors flex items-center gap-2 text-sm font-medium"
        >
          <User className="w-4 h-4" />
          <span>Login</span>
        </Link>
      </header>

      <main className="flex-1 w-full max-w-xl mx-auto px-6 py-12 flex flex-col items-center">
        <div className="w-24 h-24 rounded-full bg-gray-200 mb-6 flex items-center justify-center overflow-hidden shadow-inner border border-gray-100">
          {avatarUrl ? (
            <img src={avatarUrl} alt="Dimsy Profile" className="w-full h-full object-cover" />
          ) : (
            <span className="text-3xl font-bold text-gray-400">D</span>
          )}
        </div>
        
        <h2 className="text-3xl font-bold mb-2">Dimsy</h2>
        <p className="text-gray-500 mb-10 text-center max-w-sm">
          Welcome to the official portal. Connect with me across all platforms below.
        </p>

        <div className="w-full space-y-4">
          {loading ? (
            <div className="space-y-4 w-full animate-pulse">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-16 w-full bg-gray-200 rounded-xl"></div>
              ))}
            </div>
          ) : links.length > 0 ? (
            links.map((link) => (
              <a
                key={link.id}
                href={link.url}
                target="_blank"
                rel="noopener noreferrer"
                className="group relative flex items-center justify-between p-4 px-6 w-full bg-white border border-gray-200 rounded-xl hover:border-gray-900 hover:shadow-md transition-all"
              >
                <span className="font-medium text-gray-900 group-hover:text-gray-900 transition-colors">
                  {link.title}
                </span>
                <ExternalLink className="w-5 h-5 text-gray-400 group-hover:text-gray-900 transition-colors" />
              </a>
            ))
          ) : (
            <p className="text-center text-gray-400 py-8">No links available at the moment.</p>
          )}
        </div>
      </main>

      <footer className="py-8 text-center text-gray-400 text-sm">
        &copy; {new Date().getFullYear()} Dimsy. All rights reserved.
      </footer>
    </div>
  );
}
