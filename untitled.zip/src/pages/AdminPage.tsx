import React, { useState, useEffect, useRef } from "react";
import { 
  collection, 
  query, 
  orderBy, 
  onSnapshot,
  addDoc,
  updateDoc,
  deleteDoc,
  doc,
  serverTimestamp,
  setDoc
} from "firebase/firestore";
import { signOut } from "firebase/auth";
import { db, auth } from "../lib/firebase";
import { Link, useNavigate } from "react-router-dom";
import { Plus, Trash2, Edit2, LogOut, Link as LinkIcon, Save, X, ArrowLeft, Image as ImageIcon, Upload, MessageSquare, Megaphone } from "lucide-react";

interface LinkItem {
  id: string;
  title: string;
  url: string;
  order: number;
}

export default function AdminPage() {
  const [links, setLinks] = useState<LinkItem[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Profile Settings
  const [avatarUrl, setAvatarUrl] = useState("");
  const [savingProfile, setSavingProfile] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Broadcast Settings
  const [broadcastMsg, setBroadcastMsg] = useState("");
  const [broadcastActive, setBroadcastActive] = useState(false);
  const [savingBroadcast, setSavingBroadcast] = useState(false);

  // Form states
  const [isEditing, setIsEditing] = useState<string | null>(null);
  const [title, setTitle] = useState("");
  const [url, setUrl] = useState("");
  const [order, setOrder] = useState(0);

  const navigate = useNavigate();

  useEffect(() => {
    const q = query(collection(db, "links"), orderBy("order", "asc"));
    const unsubscribeLinks = onSnapshot(q, (snapshot) => {
      const linksData = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      })) as LinkItem[];
      setLinks(linksData);
      setLoading(false);
    });

    const unsubscribeProfile = onSnapshot(doc(db, "settings", "profile"), (docSnap) => {
      if (docSnap.exists()) {
        setAvatarUrl(docSnap.data().avatarUrl || "");
      }
    });

    const unsubscribeBroadcast = onSnapshot(doc(db, "settings", "broadcast"), (docSnap) => {
      if (docSnap.exists()) {
        setBroadcastMsg(docSnap.data().message || "");
        setBroadcastActive(docSnap.data().isActive || false);
      }
    });

    return () => {
      unsubscribeLinks();
      unsubscribeProfile();
      unsubscribeBroadcast();
    };
  }, []);

  const handleLogout = async () => {
    await signOut(auth);
    navigate("/");
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement("canvas");
        const MAX_WIDTH = 256;
        const MAX_HEIGHT = 256;
        let width = img.width;
        let height = img.height;

        // Maintain aspect ratio while resizing
        if (width > height) {
          if (width > MAX_WIDTH) {
            height *= MAX_WIDTH / width;
            width = MAX_WIDTH;
          }
        } else {
          if (height > MAX_HEIGHT) {
            width *= MAX_HEIGHT / height;
            height = MAX_HEIGHT;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        ctx?.drawImage(img, 0, 0, width, height);
        
        // Convert canvas back to base64 jpeg
        const dataUrl = canvas.toDataURL("image/jpeg", 0.8);
        setAvatarUrl(dataUrl);
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleProfileSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingProfile(true);
    try {
      await setDoc(doc(db, "settings", "profile"), {
        avatarUrl
      }, { merge: true });
      alert("Profile picture saved successfully!");
    } catch (error) {
      console.error("Error updating profile:", error);
      alert("Failed to save profile picture.");
    } finally {
      setSavingProfile(false);
    }
  };

  const handleBroadcastSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingBroadcast(true);
    try {
      await setDoc(doc(db, "settings", "broadcast"), {
        message: broadcastMsg,
        isActive: broadcastActive
      }, { merge: true });
      alert("Broadcast settings saved successfully!");
    } catch (error) {
      console.error("Error updating broadcast:", error);
      alert("Failed to save broadcast settings.");
    } finally {
      setSavingBroadcast(false);
    }
  };

  const resetForm = () => {
    setIsEditing(null);
    setTitle("");
    setUrl("");
    setOrder(links.length);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !url) return;

    try {
      if (isEditing) {
        await updateDoc(doc(db, "links", isEditing), {
          title,
          url,
          order: Number(order)
        });
      } else {
        await addDoc(collection(db, "links"), {
          title,
          url,
          order: Number(order),
          createdAt: serverTimestamp()
        });
      }
      resetForm();
    } catch (error) {
      console.error("Error saving document: ", error);
      alert("Failed to save link.");
    }
  };

  const handleDelete = async (id: string) => {
    if (confirm("Are you sure you want to delete this link?")) {
      try {
        await deleteDoc(doc(db, "links", id));
      } catch (error) {
        console.error("Error deleting document: ", error);
        alert("Failed to delete link.");
      }
    }
  };

  const startEdit = (link: LinkItem) => {
    setIsEditing(link.id);
    setTitle(link.title);
    setUrl(link.url);
    setOrder(link.order);
  };

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 font-sans">
      <nav className="bg-white border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <Link to="/" className="text-gray-500 hover:text-gray-900 mr-4">
                <ArrowLeft className="w-5 h-5" />
              </Link>
              <h1 className="text-xl font-bold">Admin Dashboard</h1>
            </div>
            <div className="flex items-center">
              <button
                onClick={handleLogout}
                className="flex items-center gap-2 text-sm text-gray-600 hover:text-gray-900 transition-colors"
              >
                <LogOut className="w-4 h-4" />
                Sign Out
              </button>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Profile Settings Section */}
        <div className="bg-white shadow-sm border border-gray-200 rounded-xl p-6 mb-8">
          <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <ImageIcon className="w-5 h-5 text-gray-400" />
            Profile Settings
          </h2>
          <form onSubmit={handleProfileSubmit} className="space-y-4">
            <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center">
              <div className="relative group cursor-pointer" onClick={() => fileInputRef.current?.click()}>
                {avatarUrl ? (
                  <img src={avatarUrl} alt="Profile Preview" className="w-20 h-20 rounded-full object-cover border-2 border-gray-200" />
                ) : (
                  <div className="w-20 h-20 rounded-full bg-gray-100 border-2 border-dashed border-gray-300 flex items-center justify-center text-gray-400">
                    <Upload className="w-6 h-6" />
                  </div>
                )}
                <div className="absolute inset-0 bg-black/40 rounded-full opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white text-xs font-medium">
                  Change
                </div>
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium text-gray-900 mb-1">Upload new profile picture</p>
                <p className="text-xs text-gray-500 mb-3">Square image recommended. Will be resized automatically.</p>
                <input
                  type="file"
                  accept="image/*"
                  ref={fileInputRef}
                  onChange={handleImageUpload}
                  className="hidden"
                />
                <button
                  type="submit"
                  disabled={savingProfile || !avatarUrl}
                  className="inline-flex justify-center py-2 px-4 border border-transparent rounded-lg shadow-sm text-sm font-medium text-white bg-gray-900 hover:bg-black focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-900 transition-colors disabled:opacity-50"
                >
                  <Save className="w-4 h-4 mr-2" />
                  {savingProfile ? "Saving..." : "Save Picture"}
                </button>
                {avatarUrl && (
                  <button
                    type="button"
                    onClick={() => { setAvatarUrl(""); fileInputRef.current && (fileInputRef.current.value = ""); }}
                    className="ml-2 text-sm text-red-500 hover:text-red-700 font-medium"
                  >
                    Clear
                  </button>
                )}
              </div>
            </div>
          </form>
        </div>

        {/* Broadcast Settings Section */}
        <div className="bg-white shadow-sm border border-gray-200 rounded-xl p-6 mb-8">
          <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <Megaphone className="w-5 h-5 text-gray-400" />
            Broadcast Banner
          </h2>
          <form onSubmit={handleBroadcastSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Message</label>
              <textarea
                rows={2}
                value={broadcastMsg}
                onChange={(e) => setBroadcastMsg(e.target.value)}
                className="w-full border-gray-300 rounded-lg py-2 px-3 border focus:ring-gray-900 focus:border-gray-900 sm:text-sm"
                placeholder="e.g. Check out my new video!"
              />
            </div>
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="broadcastActive"
                checked={broadcastActive}
                onChange={(e) => setBroadcastActive(e.target.checked)}
                className="w-4 h-4 text-gray-900 focus:ring-gray-900 border-gray-300 rounded"
              />
              <label htmlFor="broadcastActive" className="text-sm text-gray-700 font-medium cursor-pointer">
                Show banner on homepage
              </label>
            </div>
            <button
              type="submit"
              disabled={savingBroadcast}
              className="inline-flex justify-center py-2 px-4 border border-transparent rounded-lg shadow-sm text-sm font-medium text-white bg-gray-900 hover:bg-black focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-900 transition-colors disabled:opacity-50"
            >
              <Save className="w-4 h-4 mr-2" />
              {savingBroadcast ? "Saving..." : "Save Broadcast"}
            </button>
          </form>
        </div>

        <div className="bg-white shadow-sm border border-gray-200 rounded-xl p-6 mb-8">
          <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <LinkIcon className="w-5 h-5 text-gray-400" />
            {isEditing ? "Edit Link" : "Add New Link"}
          </h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Title</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full border-gray-300 rounded-lg py-2 px-3 border focus:ring-gray-900 focus:border-gray-900 sm:text-sm"
                  placeholder="e.g. Instagram"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">URL</label>
                <input
                  type="url"
                  required
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  className="w-full border-gray-300 rounded-lg py-2 px-3 border focus:ring-gray-900 focus:border-gray-900 sm:text-sm"
                  placeholder="https://..."
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Order (Sort Index)</label>
              <input
                type="number"
                required
                value={order}
                onChange={(e) => setOrder(Number(e.target.value))}
                className="w-full sm:w-1/4 border-gray-300 rounded-lg py-2 px-3 border focus:ring-gray-900 focus:border-gray-900 sm:text-sm"
              />
            </div>
            <div className="flex gap-3 pt-2">
              <button
                type="submit"
                className="inline-flex justify-center py-2 px-4 border border-transparent rounded-lg shadow-sm text-sm font-medium text-white bg-gray-900 hover:bg-black focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-900 transition-colors"
              >
                <Save className="w-4 h-4 mr-2" />
                {isEditing ? "Save Changes" : "Add Link"}
              </button>
              {isEditing && (
                <button
                  type="button"
                  onClick={resetForm}
                  className="inline-flex justify-center py-2 px-4 border border-gray-300 rounded-lg shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-900 transition-colors"
                >
                  <X className="w-4 h-4 mr-2" />
                  Cancel
                </button>
              )}
            </div>
          </form>
        </div>

        <div className="bg-white shadow-sm border border-gray-200 rounded-xl overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-200 bg-gray-50">
            <h3 className="text-lg font-medium leading-6 text-gray-900">Manage Links</h3>
          </div>
          <ul className="divide-y divide-gray-200">
            {loading ? (
              <li className="px-6 py-4 text-center text-gray-500">Loading links...</li>
            ) : links.length > 0 ? (
              links.map((link) => (
                <li key={link.id} className="px-6 py-4 flex items-center justify-between hover:bg-gray-50 transition-colors">
                  <div className="flex flex-col">
                    <span className="text-sm font-medium text-gray-900">{link.title}</span>
                    <span className="text-sm text-gray-500 truncate max-w-xs sm:max-w-md">{link.url}</span>
                    <span className="text-xs text-gray-400 mt-1">Order: {link.order}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => startEdit(link)}
                      className="p-2 text-gray-400 hover:text-blue-600 transition-colors rounded-lg hover:bg-blue-50"
                      title="Edit"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDelete(link.id)}
                      className="p-2 text-gray-400 hover:text-red-600 transition-colors rounded-lg hover:bg-red-50"
                      title="Delete"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </li>
              ))
            ) : (
              <li className="px-6 py-8 text-center text-gray-500">No links added yet.</li>
            )}
          </ul>
        </div>
      </main>
    </div>
  );
}
